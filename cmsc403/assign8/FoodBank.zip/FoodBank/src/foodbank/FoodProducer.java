package foodbank;

import java.util.Random;
/*
    * A class FoodProducer
	FoodProducer will have a single instance variable named bank of type FoodBank.
	* FoodProducer will have a parameterized constructor with a single parameter of type FoodBank.
	* The parameterized constructor will initialize the value of bank to the single parameter.
	* FoodProducer will extend the Thread class and override Thread’s run method.
	* FoodProducer’s run method will loop infinitely. On each loop iteration run will
	* generate a random number from 1-100 and add that much food to the bank instance variable.
	* After adding food, the thread will sleep for 100 milliseconds. */

class FoodProducer extends Thread {
    private final FoodBank bank;
    private final Random random;

    public FoodProducer(FoodBank bank) {
        this.bank = bank;
        this.random = new Random();
    }

    @Override
    public void run() {

        while (true) {
            int amount = random.nextInt(100)+1;
            bank.giveFood(amount);

            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                return;
            }
        }
    }
}