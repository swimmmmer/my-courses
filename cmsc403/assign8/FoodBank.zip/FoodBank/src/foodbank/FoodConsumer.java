package foodbank;

import java.util.Random;
/*
FoodConsumer is identical to FoodProducer except that the random number
generated in run will be removed from the FoodBank object.
*/
class FoodConsumer extends Thread {
    private final FoodBank bank;
    private final Random random;

    public FoodConsumer(FoodBank bank) {
        this.bank = bank;
        this.random = new Random();
    }

    @Override
    public void run() {

        while (true) {
            int amount = random.nextInt(100)+1;
            bank.takeFood(amount);

            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                return;
            }
        }
    }
}
