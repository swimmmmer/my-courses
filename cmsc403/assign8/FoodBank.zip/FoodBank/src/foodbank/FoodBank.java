package foodbank;

/*
A class FoodBank
FoodBank will have a single instance variable named food of type int.
FoodBank will define a default constructor which initializes food to zero.
FoodBank will have two methods: giveFood and takeFood.
Both methods will have a single parameter of type int.
giveFood will add the value of the parameter to the food instance variable,
takeFood will subtract the value.
*/
class FoodBank {
    private int food;

    public FoodBank() {
        food = 0;
    }

    public synchronized void giveFood(int amount) {
        while (amount <= 0) {
            try {
                wait();
            } catch (InterruptedException e) {
                return;
            }
        }
        food += amount;
        System.out.println("Added " + amount + " units of food. Total food: " + food);
        notifyAll();
    }

    public synchronized void takeFood(int amount) {
        while (amount > food) {
            try {
                wait();
            } catch (InterruptedException e) {
                return;
            }
        }
        food -= amount;
        System.out.println("Took " + amount + " units of food. Total food: " + food);
        notifyAll();
    }
}
