Name: Javeria Hanif
V#: V01009229
Program Manual: To compile the client and server on virtual machine, use 'javac
PINGClient.java' (for client) and 'javac PINGServer.java' (for server). To execute
the programs, do the following in this format:
'java PINGClient 10.0.0.2 10530 3333 100 2' for PINGClient and
'java PINGServer 10530 30' for PINGServer program.